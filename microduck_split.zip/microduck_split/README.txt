Microduck print split (source: AI-FanGe/Microduck-build-tutorial, MIT licence)

NylonG_PulseXE/  beds laid out for 250 x 220 mm
  N0_test_piece    one servo bracket - print first, check fit and shrink
  N1_frame_1, _2   the 19 "gray structural parts" (minus the test piece)
  N2_legs_feet_1   2 leg links + 2 foot housings
PLA_Prusa/       beds laid out for 250 x 210 mm
  P1_shells_beak_1     big shell, 2 covers, 2 beak parts
  P2_soles_ring_1      2 soles, 1 ring
  P3_bearings_horns_1  34 rings/horns/caps + 2 spare idle horns
individual_STL/ in each folder: every part as its own STL, already in the
author's print orientation, in case your slicer will not open the 3MF.

Parts keep the author's orientation. Original settings: 0.4 mm nozzle,
0.2 mm layers, 2 walls, 15% infill, supports ON. No slicer settings are
stored in these files - set them yourself.
File names: plate<original plate>_<my label>_<original name>_id<n>.
Labels are my best reading of the geometry, not the author's names.
